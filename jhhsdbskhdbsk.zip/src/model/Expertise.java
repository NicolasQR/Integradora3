package model;

public enum Expertise {
    
    Ofensivo, Defendia, Posesion, JugadasDeLaboratorio
    
}
