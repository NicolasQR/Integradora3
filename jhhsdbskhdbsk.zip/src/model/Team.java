package model;

public class Team {
    
}
