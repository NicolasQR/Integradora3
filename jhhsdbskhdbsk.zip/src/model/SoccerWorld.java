package model;

public interface SoccerWorld {
    
    public void calculateMarketPrice();
    
    public void calculateStarts();
    
}
