package model;

public enum Position {
   
    Portero, Defensor, Volante, Delantero
    
}
